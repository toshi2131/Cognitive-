namespace CognitiveTestEngine.Core
{
    public static class Global2
    {
        public static int guessesCount = 0;
        public static string BUTTON_TAG = "Button";
    }  
}
